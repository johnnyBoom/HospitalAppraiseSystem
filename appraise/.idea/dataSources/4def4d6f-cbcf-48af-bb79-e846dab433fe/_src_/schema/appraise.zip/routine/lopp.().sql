CREATE PROCEDURE lopp()
  begin
    declare i int ;
    set i = 1;

    lp1 : LOOP
    insert into departments (uid) values ("内科" + i);
    set i = i+1;
    if i > 30 then
      leave lp1;
  end if;
end LOOP;
end;
