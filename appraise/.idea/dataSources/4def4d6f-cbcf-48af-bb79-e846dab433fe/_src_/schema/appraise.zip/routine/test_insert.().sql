CREATE PROCEDURE test_insert()
  BEGIN
    DECLARE y TINYINT DEFAULT 3;
    WHILE y<20
    DO
      insert into departments(name) values(concat('内科',y));
      SET y=y+1;
    END WHILE ;
    commit;
  END;
