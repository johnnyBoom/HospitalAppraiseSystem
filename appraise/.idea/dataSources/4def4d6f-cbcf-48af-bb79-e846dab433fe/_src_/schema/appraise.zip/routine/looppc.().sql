CREATE PROCEDURE looppc()
  begin
    declare i int;
    set i = 1;

    repeat
      insert into departments (name) values ("内科" + i);
      set i = i + 1;
    until i >= 20

    end repeat;


  end;
